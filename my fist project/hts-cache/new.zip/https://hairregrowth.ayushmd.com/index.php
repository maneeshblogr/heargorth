
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Hair loss Treatment</title>

  <!-- css -->
  <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
  <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<!--   <link rel="stylesheet" type="text/css" href="plugins/cubeportfolio/css/cubeportfolio.min.css"> -->
  <!-- <link href="css/nivo-lightbox.css" rel="stylesheet" />
  <link href="css/nivo-lightbox-theme/default/default.css" rel="stylesheet" type="text/css" /> -->
 <!--  <link href="css/owl.carousel.css" rel="stylesheet" media="screen" />
  <link href="css/owl.theme.css" rel="stylesheet" media="screen" /> -->
  <!-- <link href="css/animate.css" rel="stylesheet" /> -->
  <link href="css/style.css" rel="stylesheet">
<!--   <link rel="stylesheet" href="css/lightslider.css" type="text/css"  /> -->
  <!-- boxed bg -->
<!--   <link id="bodybg" href="bodybg/bg1.css" rel="stylesheet" type="text/css" /> -->
  <!-- template skin -->
  <link id="t-colors" href="color/default.css" rel="stylesheet">
  <link rel="icon" href="favicon.png" type="image/gif" sizes="32x32"> 
<!--   <link rel="stylesheet" href="countdown/css/styles.css" />
  <link rel="stylesheet" href="countdown/countdown/jquery.countdown.css" /> -->

      <style type="text/css">
         /* The Modal (background) */
.modal2 {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}

/* Modal Content/Box */
.modal-content2 {
  background-color: #fefefe;
  margin: 8% auto; /* 15% from the top and centered */
  padding: 20px;
  border: 1px solid #888;
  width: 40%; /* Could be more or less, depending on screen size */
}

/* The Close Button */
.close2 {
  color: #aaa;
  float: right;
  font-size: 28px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: black;
  text-decoration: none;
  cursor: pointer;
} 

/*popup form style start from here*/
  #regForm {
  background-color: #ffffff;
  margin: 0px auto;
  font-family: Raleway;
  padding: 5px;
  width: 40%;
  min-width: 375px;
  border-radius:10px;
}
.heading-h1 {
  text-align: center;  
}
input {
  padding: 10px;
  width: 100%;
  font-size: 17px;
  font-family: Raleway;
  border: 1px solid #aaaaaa;
}
input.invalid {
  background-color: #ffdddd;
}
.tab {
  display: none;
}
.dbtn {
  background-color: #4CAF50;
  color: #fff;
  border: none;
  padding: 10px 20px;
  font-size: 17px;
  font-family: Raleway;
  cursor: pointer;
}
.dbtn:hover {
  opacity: 0.8;
}
#prevBtn {
  background-color: #bbbbbb;
}
.step {
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbbbbb;
  border: none;  
  border-radius: 50%;
  display: inline-block;
  opacity: 0.5;
}
.step.active {
  opacity: 1;
}
.step.finish {
  background-color: #4CAF50;
}

.popup-box-heading{   
    text-align: center;
    font-size: 28px;
    margin-top: 0px;
    color: #ffffffed;
    background-color:#e9372e;
    padding: 10px;
    line-height: 1.3;
    font-weight: 600;
}

.modal-dialog {

    width: 460px;
    margin: 30px auto;
    z-index: 100000;

}

.modal-body {

    position: relative;
    padding: 20px;
    padding-top: 5px;
    padding-bottom: 0px;

}

.modal-title{
  font-size:24px;
  font-weight: 600;
  color: #FFF;
}

.modal-header {
    min-height: 16.43px;
    padding: 15px;
    border-bottom: 1px solid #e5e5e5;
    background-color:#5cb85c;
  }
.modal-header .close {
    margin-top: -48px;
}
.modal-footer {

    padding: 15px;
    text-align: center;
    border-top: 1px solid #e5e5e5;
  }

/* .positive{
  position: relative;
  background: url(img/positive-result.png) top center no-repeat;  
  text-align: center;
  padding: 42px 40px;
  float: left;
  margin-top: 170px;
  z-index: 1;
 } */

/* .positive {
    position: relative;
    background: url(img/positive-result.png) no-repeat;        
    text-align: center;
    padding: 42px 40px;    
    margin-top: -40px;
    z-index: 1000;
    background-position: 260px 0px;
  
    background-size: 116px;
}*/

.positive {
    position: relative;
    background: url(img/positive-result.png) no-repeat;
       
    text-align: center;
    padding: 31px 40px;
    margin-top: 0px;
    z-index: 1000;
    background-position: 10px 5px;    
    background-size: 80px;
}

.treatement-heading{
  text-align: center; margin-top: 20px; margin-bottom: 10px;padding-left:20px;
}
.navbar-header{
  width:40%;
}
.call-whatsapp{
  margin-top: 26px;
}
.whatsapp_icon{
  height: 30px; width: auto; margin-bottom: 3px;
}
.call-whatsapp a{
  font-size: 22px;
}

.countdownHolder {
    width: 450px;
    margin: 0 0;
    font: 40px/1.5 'Open Sans Condensed',sans-serif;
    text-align: left;
    letter-spacing: -3px;
}


#note {
    color: #666666;
    font-size: 12px;
    margin: 0 0;
    padding: 4px;
    text-align: left;
    text-shadow: 1px 1px 0 rgba(255, 255, 255, 0.3);
    width: 400px;
}
.our-results-heading{
  width: 55%; margin: auto;
  }

 .strikethrough {
    position: relative;
  }
  .strikethrough:before {
    position: absolute;
    content: "";
    left: 0;
    top: 50%;
    right: 0;
    border-top: 1px solid;
    border-color: inherit;

    -webkit-transform:rotate(-5deg);
    -moz-transform:rotate(-5deg);
    -ms-transform:rotate(-5deg);
    -o-transform:rotate(-5deg);
    transform:rotate(-5deg);
  } 
  .offer-countdown{
   color: #000; font-size: 18px;
  }

  .btn-2 {
      display: inline-block;
      padding: 11px 57px;
    }

   .mobile-group{
    display: none;
   } 
   .modal-title{
    margin-bottom: 0px; font-size: 18px; font-weight: 600; text-transform: uppercase;
    color: #5cb85c;
   }

  .highlights{
    letter-spacing: -0.3px;
    font-size: 11px;
    font-weight: 400;
    margin-bottom: 0px;
  }

  .modal-open {
    overflow: scroll;
}

.md-form{
  margin-top: 16px;

}

.highlights-box {margin-bottom: 0px; margin-top: 16px;}

.verified-customer{
  color:green; font-size:12px; font-weight:600;
}

.rating-user{
  font-size: 14px !important;
  color: #555;
}
.modal-backdrop {
    position: fixed;
    top: 71px;
    right: 0;
    bottom: 0;
    left: 0;
    background-color: #000000ad;
}
.modal-dialog {
    width: 460px;
    margin: 34px auto;
    z-index: 100000;
}

.modal {
  top:75px;
}

.carousel-control.left {
    left: 20px;
    top: 0px;
}

.carousel-control.right {
    right: 20px;
    top: 0px;
}

/* Chrome, Safari, Edge, Opera */
input::-webkit-outer-spin-button,
input::-webkit-inner-spin-button {
  -webkit-appearance: none;
  margin: 0;
}

/* Firefox */
input[type=number] {
  -moz-appearance:textfield;
}

.call-icon-block {width: 48%; display: inline-block; text-align: center;}

.whatsapp_icon {
    height: 50px;
    width: auto;
    margin-bottom: 0px;
}
.call_icon {
    height: 50px;
    width: auto;
    margin-bottom: 0px;
}

.hindi-heading{
  font-size: 18px;
}
.hindi-option{
  font-size: 15px;
}

@media screen and (max-width:35em) {
  body {
    font-family: 'Open Sans', sans-serif;
    font-weight: 300;
    color: 
    #666;
    font-size: 13px;
    line-height: 1.6em;
  }
  .navbar-header{
    width:auto;
  }

  .treatement-heading {
      text-align: right;
      margin-top: 20px;
      margin-bottom: 10px;
      font-size: 23px;
  }
  ul.lead-list li span.fa {
    margin: 5px 5px 0 0;
    float: none;
  }
  ul.lead-list li span.list {
      display: inline;
      margin: 0 0 0 10px;
  }

  .modal-title{
        margin-bottom: 0px;
  }

  .positive {
      position: relative;
      background: url(img/positive-result.png) no-repeat;
          
      text-align: left;
      padding: 38px 18px;
      margin-top: -40px;
      z-index: 1000;
      background-position: 0px 0px;
      background-size: 99px;

  }

  .treatment-sub-heading{
    margin-left: 95px;
  }

  .modal-dialog {
    width: 360px;
    margin: 5px auto;
    z-index: 100000;
  }

  .call-whatsapp {
    margin-top: 18px;
}
  .navbar-header {
    width: 100%;
  }
  .our-results-heading{
    width: 90%; margin: auto;
  }
  .offer-countdown{
    display: block;
  }
  .h-light{
    font-size: 26px;
  }

  .modal-body {
    position: relative;
    padding: 14px;
        padding-top: 24px;
      padding-top: 10px;
  }

  .btn-2 {
    display: inline-block;
    padding: 8px 40px;
  }

  .modal-backdrop {
    position: fixed;
    top: 67px;
    right: 0;
    bottom: 0;
    left: 0;
    background-color: #0000006b;
  }
  .modal-dialog {
      width: 360px;
      margin: 37px auto;
      z-index: 100000;
  }

.highlights-box {margin-bottom: 0px; margin-top: 1px;}

.intro-content {
    /*background: url(../img/dummy/bg1.jpg) no-repeat top center;*/
    padding: 304px 0 0px;
}

.treatement-heading {
    text-align: center;
    margin-top: 20px;
    margin-bottom: 10px;
    font-size: 23px;
    padding-left: 0px;
}

ul.lead-list li {
    margin: 0 0 10px 0;
    line-height: 1.6em;
}
.well {
    min-height: 20px;
    padding: 10px;
    margin-bottom: 5px;
    background-color: #f5f5f5;
    border: 1px solid #e3e3e3;
    border-radius: 4px;
    -webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.05);
    box-shadow: inset 0 1px 1px rgba(0,0,0,.05);
}
h1, h2, h3, h4, h5, h6 {
    margin: 0 0 15px;
    font-family: 'Roboto', sans-serif;
    font-weight: 400;
    color: #444;
    line-height: 1em;
}

.h-light {
    font-size: 24px;
}

ul.lead-list li {
    margin: 0 0 0px 0;
    line-height: 1.6em;
}
.box {
    padding: 5px;
}
.box h4 {
    font-size: 16px;
    margin-bottom: 5px;
}
.box i {
    margin-bottom: 15px;
}
p {
    margin: 0 0 5px;
}
.paddingtop-80 {
    padding-top: 40px !important;
}
h3 {
    font-size: 25px;
}
.fa-3x {
    font-size: 2.3em;
}
.service-icon {
    margin: 0 6px 45px 0;
    float: left;
}
.service-desc h5 {
    margin-bottom: 5px;
}
.h-light {
    font-size: 19px;
}

.carousel-control {
    position: absolute;
    top: 0%;
    bottom: 0;
    left: 0;
    width: auto;
    font-size: 20px;
    color: #fff;
    text-align: center;
    text-shadow: 0 1px 2px rgba(0, 0, 0, .6);
    filter: alpha(opacity=50);
    opacity: .5;
}
.glyphicon-chevron-right:before {
    content: "\e080";
    color: #0b9a03;
}
.glyphicon-chevron-left:before {
    content: "\e079";
    color: #0b9a03;
}

.#duraion_of_hair_loss{
  font-size: 12px !important;
}
.form-control {
  font-size: 12px;
  }

  .navbar-toggle {
    position: relative;
    float: right;
  /*  padding: 9px 10px;*/
    margin-top: 15px;
    margin-right: 0px;
    margin-bottom: 3px;
   /* background-color: transparent;*/
    background-image: none;
    border: 1px solid transparent;
    border-radius: 4px;
}

.modal{
  top: 40px;
}

}

.btn-2 {
    display: inline-block;
    padding: 4px 50px !important;
}

.befor-img{
  border: 1px solid gray
}
.befor-img img{width:100%; height:auto;}

/*.doctor_online{
  display: inline; font-size: 10px; color: yellow; margin-left: -20%;
}*/

.doctor_online{
 font-size: 20px; color: yellow; text-align: center;
}

@media screen and (max-width:35em) {
.doctor_online {
    display: block;
    font-size: 13px;
    color: yellow;
    margin: auto;
    width: 74%;
}

.intro-content {
    /*background: url(../img/dummy/bg1.jpg) no-repeat top center;*/
    padding: 85px 0 0px;
}
.main-heading{
  font-size: 25px !important;
}

.hindi-heading {
    font-size: 16px;
}
.h3-small {
    font-size: 20px;text-align: center; margin-top: 15px;
}

.img-res{
  display: block;
    max-width: 60%;
    height: auto;
    margin: auto;
}
}

}

/*CSS FOR MALE AND FEMALE SELECTION*/
@import url(https://fonts.googleapis.com/css?family=Lato);
html,


label{
  user-select: none;
}
input[type="radio"] {
  display: none;
}

input[type="radio"] + label {
  z-index: 10;
  margin: 0 10px 10px 0;
  position: relative;
  color: #949494;
  text-shadow: 0 1px 0 rgba(255, 255, 255, 0.1);
  font-weight: bold;
  background-color: #ffffff;
  border: 2px solid #ced4da;
  cursor: pointer;
  transition: all 200ms ease;
}

input[type="radio"]:checked + label {
  color: #495057;
  background-color: #fbec73;
}

input[type="radio"] + label {
  padding: 5px 20px;
  border-radius: 10px;
}

.main-heading{color: white; text-align: center; font-weight: 600; font-size: 34px;}

/*END*/



/*popup form style End from here*/
</style>
</head>

<body id="page-top" data-spy="scroll" data-target=".navbar-custom" style="background: #FFF;">


  <div id="wrapper">

       <nav class="navbar navbar-custom navbar-fixed-top" role="navigation">

      <div class="container navigation">

        <div class="navbar-header page-scroll" >
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-main-collapse">
                    <i class="fa fa-bars"></i>
                </button>

          <a class="navbar-brand" href="index.php">
                    <img src="img/logo.png" alt="" width="150" height="40" />
                 
                </a>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse navbar-right navbar-main-collapse">
          <ul class="nav navbar-nav">
            <li class="active"><a href="#intro">Home</a></li>
            <li><a href="#service">View Report</a></li>
            <li><a href="#doctor">Contact</a></li>
            <li><a href="#facilities">For Doctors</a></li>
    
          </ul>
        </div>
        <!-- /.navbar-collapse -->
      </div>
      <!-- /.container -->
    </nav>
    <!-- Popup for by deepak start here -->

    <!-- The Modal -->


    


    <!-- Popup for by deepak end here -->

    <!-- Section: intro -->
    <section id="intro" class="intro">
      <div class="intro-content">
        <div class="container">
          <div class="row">
           <!--  <button id="myBtn" class="btn btn-success">Book an Appointment</button> -->
           <div class="col-sm-12 hidden-lg hidden-md">
              <div class="wow fadeInUp" data-wow-duration="2s" data-wow-delay="0.2s">
                <img src="img/dummy/img-1.png" class="img-responsive img-res" alt="" />
              </div>
            </div>

            <div class="col-lg-9">
              <div class="wow fadeInDown" data-wow-offset="0" data-wow-delay="0.1s">
                 <h2 class="h-ultra main-heading">Stop Hair Fall Now<br><span class="hindi-heading">अब बालो का झड़ना रोके</span></h2>

               <h2 class="h-ultra main-heading"><span style="color: yellow;">Free Consultation</span> for Hair Fall With Hair Experts<br><span class="hindi-heading">बालो को झड़ने से रोकने के लिए बालो के विशेषज्ञ से <span style="color: yellow;">मुफ्त परामर्श</span>  ले</span></h2>

                <div  class="doctor_online col-md-12">
              <span><!-- <img src="img/icon-green-on.png" style="height: 10px; width: auto;"> -->
                <img src="img/led_blinksgreen.gif" style="width: auto; height: 25px;">
              </span>
            <span>7</span>
            <span>Doctors online</span>
            </div>

                <!-- <h3 class="h3-small" style="text-align: center;">Choose your Gender <br><span class="hindi-heading">अपना लिंग चुनें</span></h3> -->
                    
                      <div style="text-align: center; margin-top: 20px;margin-bottom: 20px;">
                            <input type='radio' class="click_sumbmit"  id="Male" value="male" name='gender'>
                            <label for='Male'><span style="color: #000;">CLICK </span><br>if you are Male</label>
                            <input type='radio' class="click_sumbmit" id="Female"  value="female" name='gender'>
                            <label for='Female'><span style="color: #000;">CLICK </span><br> if you are Female</label>
                        </div>
                   

                
              </div>
          
              <div style="margin-bottom: 75px;">
              </div>
           


            </div>
            <div class="col-lg-3 hidden-xs">
              <div class="wow fadeInUp" data-wow-duration="2s" data-wow-delay="0.2s">
                <img src="img/dummy/img-1.png" class="img-responsive img-res" alt="" />
              </div>
            </div>
          

       
</div>


        </div>
      </div>
    </section>

    <!-- /Section: intro -->

    <section id="reasult">
      <div class="container">

      
        <div class="row" style="margin-top: 10px;">
          <div class="col-md-12">
              <!-- slider section start from here -->
              <div class="our-results-heading hidden-xs">
                <div class="positive">
                  <h3 class="treatement-heading"><strong style="color: #5cb85c">10,000 + </strong> Satisfied Consultations</h3>
                <p class="treatment-sub-heading"></p>
                  
                </div>
              </div>
              <div class="row hidden-md hidden-sm hidden-lg">
                <h3 class="treatement-heading"><strong style="color: #5cb85c">10,000 + </strong> Satisfied Consultations</h3>
                <div class="col-xs-7">
                  <div class="wow fadeInUp" data-wow-duration="2s" data-wow-delay="0.2s">
                    <img src="img/dummy/img-1.1.webp" class="img-responsive" alt="" />
                  </div>
                </div>
                <div class="col-xs-5">
                  <div class="wow fadeInUp" data-wow-duration="2s" data-wow-delay="0.2s">
                    <img src="img/positive-result.png" class="img-responsive" alt="" style="margin-top: 15px;" />
                  </div>
                </div>
             </div>

            
                
              
                <!--  <ul id="content-slider" class="content-slider" style="margin-top: 10px;">
                        <li>
                          <div style="border: 1px solid gray">
                            <img src="img/hair/img/img-1.webp" style="width:100%; height:auto;">
                          </div>
                        </li>                      
                        <li>
                          <div style="border: 1px solid gray">
                            <img src="img/hair/img/img-3.webp" style="width:100%; height:auto;">
                          </div>
                        </li>

                        <li>
                          <div style="border: 1px solid gray">
                            <img src="img/hair/img/img-4.webp" style="width:100%; height:auto;">
                          </div>
                        </li>
                        <li>
                          <div style="border: 1px solid gray">
                            <img src="img/hair/img/img-5.webp" style="width:100%; height:auto;">
                          </div>
                        </li>
                        <li>
                          <div style="border: 1px solid gray">
                            <img src="img/hair/img/img-6.webp" style="width:100%; height:auto;">
                          </div>
                        </li>

                        <li>
                          <div style="border: 1px solid gray">
                            <img src="img/hair/img/img-7.webp" style="width:100%; height:auto;">
                          </div>
                        </li>
                        <li>
                          <div style="border: 1px solid gray">
                            <img src="img/hair/img/img-8.webp" style="width:100%; height:auto;">
                          </div>
                        </li>



                        
                    </ul> -->

             
          </div>
           <div class="row" id="befor_after_img">
            
               
          </div>
          
        </div>
        
      </div>
      
    </section>

    <!-- Section: boxes -->
    <section id="boxes" class="home-section paddingtop-80">

      <div class="container">
        <div class="row">
          <div class="col-sm-3 col-md-3 col-xs-6">
            <div class="wow fadeInUp" data-wow-delay="0.2s">
              <div class="box text-center">
                <i class="fa fa-line-chart fa-3x circled bg-skin"></i>               
                <h4 class="h-bold">10K+ Satisfied Consultations</h4>
                <p>
                  Successfully treated over 10,000+ Happy patients of Hair Loss
                </p>
              </div>
            </div>
          </div>
          <div class="col-sm-3 col-md-3 col-xs-6">
            <div class="wow fadeInUp" data-wow-delay="0.2s">
              <div class="box text-center">

                <i class="fa fa-leaf fa-3x circled bg-skin"></i>
                <h4 class="h-bold">100% Herbal Treatment</h4>
                <p>
                  Most effective herbal treatment for Hair Fall without any side effects.
                </p>
              </div>
            </div>
          </div>
          <div class="col-sm-3 col-md-3 col-xs-6">
            <div class="wow fadeInUp" data-wow-delay="0.2s">
              <div class="box text-center">
                <i class="fa fa-user-md fa-3x circled bg-skin"></i>
                <h4 class="h-bold">50+ Hair Experts</h4>
                <p>
                  Experience Team in proven hair loss treatments
                </p>
              </div>
            </div>
          </div>
          <div class="col-sm-3 col-md-3 col-xs-6">
            <div class="wow fadeInUp" data-wow-delay="0.2s">
              <div class="box text-center">

                <!-- <i class="fa fa-hospital-o fa-3x circled bg-skin"></i> -->
                 <i class="fa fa-check fa-3x circled bg-skin"></i>
                <h4 class="h-bold">94.6% success rate </h4>
                <p>
                  94.6% Of Hair Patients are satisfied and will not switch to conventional treatments.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

    </section>
    <!-- /Section: boxes -->

    <!-- enquiry Modal by deepak  -->




    <!-- deepak end -->


    <section id="callaction" class="home-section paddingtop-40">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="callaction bg-gray">
              <div class="row">
                <div class="col-md-8">
                  <div class="wow fadeInUp" data-wow-delay="0.1s">
                    <div class="cta-text">
                      <h1 style="font-size: 32px;">Why AyushMD™ for hair fall treatment?</h1>
                      <p>At AyushMD™, we provide a holistic hair loss treatment that goes to the root of the problem. Our hair specialists recommend natural and safe medicines to treat hair loss. They also advise on advanced treatments to control hair fall for better and long-lasting results. </p>
                    </div>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="wow lightSpeedIn" data-wow-delay="0.1s">
                    <div class="cta-btn">
                      <a href="#" class="btn btn-skin btn-lg" id="book-an-appointment">Book an appoinment</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>


    <!-- Section: services -->
    <section id="service" class="home-section nopadding paddingtop-60">

      <div class="container">

        <div class="row">
          <div class="col-sm-6 col-md-6">
            <div class="wow fadeInUp" data-wow-delay="0.2s">
              <img src="img/dummy/look.jpg" class="img-responsive" alt="" />
            </div>
          </div>
          <div class="col-sm-3 col-md-3 col-xs-6">

            <div class="wow fadeInRight" data-wow-delay="0.1s">
              <div class="service-box">
                <div class="service-icon">
                  <span class="fa fa-h-square fa-3x"></span>
                </div>
                <div class="service-desc">
                  <h5 class="h-light">Hair Care</h5>
                  <p>Let Hair Loss not take away your confidence.</p>
                </div>
              </div>
            </div>

            <div class="wow fadeInRight" data-wow-delay="0.2s">
              <div class="service-box">
                <div class="service-icon">
                  <span class="fa fa-plus-square  fa-3x"></span>
                </div>
                <div class="service-desc">
                  <h5 class="h-light">Skin Care</h5>
                  <p>Safe & Effective Treatment for Skin Problem</p>
                </div>
              </div>
            </div>
            <div class="wow fadeInRight" data-wow-delay="0.3s">
              <div class="service-box">
                <div class="service-icon">
                  <span class="fa fa-wheelchair fa-3x"></span>
                </div>
                <div class="service-desc">
                  <h5 class="h-light">Ortho Care</h5>
                  <p>Help ease the pain in joints by repairing the cusion</p>
                </div>
              </div>
            </div>


          </div>
          <div class="col-sm-3 col-md-3 col-xs-6">

            <div class="wow fadeInRight" data-wow-delay="0.1s">
              <div class="service-box">
                <div class="service-icon">
                  <span class="fa fa-stethoscope fa-3x"></span>
                </div>
                <div class="service-desc">
                  <h5 class="h-light">Immune Care</h5>
                  <p>By Nature made and other immune support formulas.</p>
                </div>
              </div>
            </div>

            <div class="wow fadeInRight" data-wow-delay="0.2s">
              <div class="service-box">
                <div class="service-icon">
                  <span class="fa fa-medkit fa-3x"></span>
                </div>
                <div class="service-desc">
                  <h5 class="h-light">Diabetes Care</h5>
                  <p>Prevention and treatment of Diabetes</p>
                </div>
              </div>
            </div>
            <div class="wow fadeInRight" data-wow-delay="0.3s">
              <div class="service-box">
                <div class="service-icon">
                  <span class="fa fa-user-md fa-3x"></span>
                </div>
                <div class="service-desc">
                  <h5 class="h-light">& Many More</h5>
                  <p>Proven treatment of many different diseases</p>
                </div>
              </div>
            </div>

          </div>

        </div>
      </div>
    </section>
  


    <!-- Section: testimonial -->
    <section id="testimonial" class="home-section paddingbot-60 parallax" data-stellar-background-ratio="0.5">

      <div class="carousel-reviews broun-block">
        <div class="container">
          <div class="row">
            <div id="carousel-reviews" class="carousel slide" data-ride="carousel">

              <div class="carousel-inner">
                <div class="item active">
                  <div class="col-md-6 col-sm-12">
                    <div class="block-text rel zmin">
                      <a title="" href="#">Highly recommended by me</a>
                      <div class="mark">My rating: <span data-value="0" class="glyphicon glyphicon-star"></span>
                        <span data-value="2" class="glyphicon glyphicon-star"></span>                        
                        <span data-value="2" class="glyphicon glyphicon-star"></span>
                        <span data-value="2" class="glyphicon glyphicon-star"></span>
                       <span data-value="2" class="glyphicon glyphicon-star"></span>
                      </div>
                      <p>For years my hair has been thinning and breaking like crazy and I have tried several products.Finally I consulted with AYushMD Hair Specialists. They Suggested some medicine then I  purchased medicine from amazon and it is changed the feel and thickness of my hair.Highly recommended by me.</p>
                      </br>

                     
                      <a title="" href="#" class="rating-user">Amit Gupta</a><span> Delhi, India</span></br>
                       <span class="verified-customer">
                        <i class="fa fa-check-circle" aria-hidden="true"></i> Verified Customer</span>
                      
                    </div>
                
                  </div>

                  <div class="col-md-6 col-sm-12 hidden-xs">
                    <div class="block-text rel zmin">
                      <a title="" href="#">Controlled the massive hair fall</a>
                      <div class="mark">My rating:
                        <span class="rating-input">

                        <span data-value="0" class="glyphicon glyphicon-star"></span>
                        <span data-value="2" class="glyphicon glyphicon-star"></span>                        
                        <span data-value="2" class="glyphicon glyphicon-star"></span>
                        <span data-value="2" class="glyphicon glyphicon-star"></span>
                        <span data-value="2" class="glyphicon glyphicon-star-empty"></span>
                    
                      </span>
                      </div>
                      <p>I've been using AyushMD's Consultation for the past 3 weeks or so and their Herbal Medicine significantly controlled the massive hair fall situation that me n my sister were having previously. I'd love to continue to use their Service in future.</p>
                      </br>
                      </br>

                      <a title="" href="#">Sonia Ahuja</a><span> Gurgaon, India</span></br>
                       <span class="verified-customer">
                        <i class="fa fa-check-circle" aria-hidden="true"></i> Verified Customer</span>

                    </div>
                 
                  </div>            

                </div>
                <div class="item">
                  <div class="col-md-6 col-sm-12 ">
                    <div class="block-text rel zmin">
                      <a title="" href="#">Hair Fall</a>
                      <div class="mark">My rating: 
                        <span class="rating-input">

                        <span data-value="0" class="glyphicon glyphicon-star"></span>
                        <span data-value="2" class="glyphicon glyphicon-star"></span>                        
                        <span data-value="2" class="glyphicon glyphicon-star"></span>
                        <span data-value="2" class="glyphicon glyphicon-star"></span>
                        <span data-value="2" class="glyphicon glyphicon-star-empty"></span>
                    
                      </span>
                      </div>
                      <p>I am really satisfy with this Free Consultation and in 12 days i got 95% of less hair fall. Thanks a lot</p>
                    </br>
                    </br>
                    </br>
                    </br>

                    <a title="" href="#" class="rating-user">Niharika Joshi</a><span> Gaziabad, India</span></br>
                       <span class="verified-customer">
                        <i class="fa fa-check-circle" aria-hidden="true"></i> Verified Customer</span>

                    </div>
                 
                  </div>

                  <div class="col-md-6 col-sm-12 hidden-xs">
                    <div class="block-text rel zmin">
                      <a title="" href="#">I can see visible effect on hair fall.</a>
                      <div class="mark">My rating: 
                        <span class="rating-input">

                        <span data-value="0" class="glyphicon glyphicon-star"></span>
                        <span data-value="2" class="glyphicon glyphicon-star"></span>                        
                        <span data-value="2" class="glyphicon glyphicon-star"></span>
                        <span data-value="2" class="glyphicon glyphicon-star"></span>
                       <span data-value="2" class="glyphicon glyphicon-star"></span>
                    
                      </span>
                      </div>
                      <p>Thanks to AyushMD team. I have been using your herbal Medicine as per your prescription since 2 weeks I can see visible effect on hair fall.. i had excess hair fall after my baby.. its like hairs r faling everywer i was ever scared to comb them or wash them... now the situation is improving and I wil give you expected results by end of the month...</p>
                      </br>

                       <a title="" href="#" class="rating-user">Rupali Das</a><span> Kolkata, India</span></br>
                       <span class="verified-customer">
                        <i class="fa fa-check-circle" aria-hidden="true"></i> Verified Customer</span>

                    </div>
                   
                  </div>
                  
                </div>
                <div class="item">
          
                  <div class="col-md-6 col-sm-12">
                    <div class="block-text rel zmin">
                      <a title="" href="#">Decently controlled the hair fall issue</a>
                      <div class="mark">My rating: <span class="rating-input">

                        <span data-value="0" class="glyphicon glyphicon-star"></span>
                        <span data-value="2" class="glyphicon glyphicon-star"></span>                        
                        <span data-value="2" class="glyphicon glyphicon-star"></span>
                        <span data-value="2" class="glyphicon glyphicon-star"></span>
                        <span data-value="2" class="glyphicon glyphicon-star-empty"></span>
                    
                      </span>
                      </div>
                      <p>After my second baby, I got the hair fall problem, it went to such level where in I thought there is some problem then I called to AyushMD. They Prescribed some medicine, After taking their medicine I can say that it decently controlled the hair fall issue but wouldn’t say it has completely reduced may be I have to use it more to solve the issue.</p>
                      </br>


                      <a title="" href="#" class="rating-user">Karishma</a><span> New Delhi, India</span></br>
                       <span class="verified-customer">
                        <i class="fa fa-check-circle" aria-hidden="true"></i> Verified Customer</span>
                    </div>                    
                  </div>
                  <div class="col-md-6 col-sm-12 hidden-xs">
                    <div class="block-text rel zmin">
                      <a title="" href="#">Treat my hair patches</a>
                      <div class="mark">My rating: <span class="rating-input">

                        <span data-value="0" class="glyphicon glyphicon-star"></span>
                        <span data-value="2" class="glyphicon glyphicon-star"></span>                        
                        <span data-value="2" class="glyphicon glyphicon-star"></span>
                        <span data-value="2" class="glyphicon glyphicon-star"></span>
                       <span data-value="2" class="glyphicon glyphicon-star"></span>
                    
                      </span>
                      </div>
                      <p>I suffered from alopecia areata with immense agony and frantically looked for a Hair specialist in Mumbai to treat my hair patches. My appointment at AyushMD for hair fall treatment was with a senior Hair Specialist who I consulted. She Prescribed me Ayurvedic Medicine to stop hair fall. AyushMD gave me my hair back and confidence in just 3 months.</p>

                      <a title="" href="#" class="rating-user">Rohan</a><span> Mumbai, India</span></br>
                       <span class="verified-customer">
                        <i class="fa fa-check-circle" aria-hidden="true"></i> Verified Customer</span>  
                    </div>                    
                  </div>
                </div>


              </div>

              <a class="left carousel-control" href="#carousel-reviews" role="button" data-slide="prev">
                    <span class="glyphicon glyphicon-chevron-left"></span>
                </a>
              <a class="right carousel-control" href="#carousel-reviews" role="button" data-slide="next">
                    <span class="glyphicon glyphicon-chevron-right"></span>
                </a>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- /Section: testimonial -->


    <section id="partner" class="home-section paddingbot-60">
      <div class="container marginbot-50">
        <div class="row">
          <div class="col-lg-8 col-lg-offset-2">
            <div class="wow lightSpeedIn" data-wow-delay="0.1s">
              <div class="section-heading text-center">
                <h2 class="h-bold">Medicine Available</h2>
                <!-- <p>Our Ayurvedic Medicine Partners</p> -->
              </div>
            </div>
            <div class="divider-short"></div>
          </div>
        </div>
      </div>

      <div class="container">
        <div class="row">
          <div class="col-sm-6 col-md-3">
            <div class="partner">
              <a href="#"><img src="img/dummy/partner-1.jpg" alt="" /></a>
            </div>
          </div>
          <div class="col-sm-6 col-md-3">
            <div class="partner">
              <a href="#"><img src="img/dummy/partner-2.jpg" alt="" /></a>
            </div>
          </div>
          <div class="col-sm-6 col-md-3">
            <div class="partner">
              <a href="#"><img src="img/dummy/partner-3.jpg" alt="" /></a>
            </div>
          </div>
          <div class="col-sm-6 col-md-3">
            <div class="partner">
              <a href="#"><img src="img/dummy/partner-4.jpg" alt="" /></a>
            </div>
          </div>
        </div>
      </div>
    </section>
<input type="hidden" name="base_url" id="base_url" value="https://hairregrowth.ayushmd.com/?>">
    <footer>

      <div class="container">
        <div class="row">
          <div class="col-sm-6 col-md-4">
            <div class="wow fadeInDown" data-wow-delay="0.1s">
              <div class="widget">
                <h5>About AyushMD</h5>
                <p>
                  AyushMD is a leading healthcare platform that provides consultations through its Clinics, Call Centers & Medical Camps.
                </p>
              </div>
            </div>
         <!--    <div class="wow fadeInDown" data-wow-delay="0.1s">
              <div class="widget">
                <h5>Information</h5>
                <ul>
                  <li><a href="#">Home</a></li>
                  <li><a href="#">Laboratory</a></li>
                  <li><a href="#">Medical treatment</a></li>
                  <li><a href="#">Terms & conditions</a></li>
                </ul>
              </div>
            </div> -->
          </div>
          <div class="col-sm-6 col-md-4">
            <div class="wow fadeInDown" data-wow-delay="0.1s">
              <div class="widget">
               <!--  <h5>AyushMD center</h5>
                <p>
                  Nam leo lorem, tincidunt id risus ut, ornare tincidunt naqunc sit amet.
                </p> -->
                <ul>
                  <li>
                    <span class="fa-stack fa-lg">
									<i class="fa fa-circle fa-stack-2x"></i>
									<i class="fa fa-calendar-o fa-stack-1x fa-inverse"></i>
								</span> Monday - Saturday, 8am to 10pm
                  </li>
                  <li>
                    <span class="fa-stack fa-lg">
									<i class="fa fa-circle fa-stack-2x"></i>
									<i class="fa fa-phone fa-stack-1x fa-inverse"></i>
								</span> 8826757757
                  </li>
                  <li>
                    <span class="fa-stack fa-lg">
									<i class="fa fa-circle fa-stack-2x"></i>
									<i class="fa fa-envelope-o fa-stack-1x fa-inverse"></i>
								</span> info@ayushmd.com
                  </li>

                </ul>
              </div>
            </div>
          </div>
          <div class="col-sm-6 col-md-4">
            
            <div class="wow fadeInDown" data-wow-delay="0.1s">
              <div class="widget">
                <h5>Follow us</h5>
                <ul class="company-social">
                  <li class="social-facebook"><a href="#"><i class="fa fa-facebook"></i></a></li>
                  <li class="social-twitter"><a href="#"><i class="fa fa-twitter"></i></a></li>
                  <li class="social-google"><a href="#"><i class="fa fa-google-plus"></i></a></li>
                  <li class="social-vimeo"><a href="#"><i class="fa fa-vimeo-square"></i></a></li>
                  <li class="social-dribble"><a href="#"><i class="fa fa-dribbble"></i></a></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="sub-footer">
        <div class="container">
          <div class="row">
            <div class="col-sm-6 col-md-6 col-lg-6">
              <div class="wow fadeInLeft" data-wow-delay="0.1s">
                <div class="text-left">
                  <p>&copy;Copyright - AyushMD Theme. All rights reserved.</p>
                </div>
              </div>
            </div>
            <div class="col-sm-6 col-md-6 col-lg-6">
              <div class="wow fadeInRight" data-wow-delay="0.1s">
                <div class="text-right">
                  <div class="credits">
               
                    Designed by <a href="https://ayushmd.com/">AyushMD</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  </div>
  <a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>

  <!-- Core JavaScript Files -->
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.min.js"></script>
 <!--  <script src="js/wow.min.js"></script> -->
  <!-- <script src="js/jquery.scrollTo.js"></script> -->
  <!-- <script src="js/jquery.appear.js"></script>
  <script src="js/stellar.js"></script>
  <script src="plugins/cubeportfolio/js/jquery.cubeportfolio.min.js"></script> -->
<!--   <script src="js/owl.carousel.min.js"></script> -->
  <!-- <script src="js/nivo-lightbox.min.js"></script> -->
  <script src="js/custom.js"></script>

  <script src="js/lightslider.js"></script>

  <script type="text/javascript" async >  

    //var base_url = 'https://localhost/hairloss/';
   //var base_url = $('#base_url').val();
   // alert(base_url)
  // var base_url = "https://hairgrowth.ayushmd.com/";
    
   //  $(document).ready(function(){
   //     $('#content-slider').lightSlider({
   //              item:3,
   //              loop:true,
   //              slideMove:2,
   //              easing: 'cubic-bezier(0.25, 0, 0.25, 1)',
   //              speed:600,
   //              auto:true,
   //              pauseOnHover: true,
   //              responsive : [
   //                  {
   //                      breakpoint:800,
   //                      settings: {
   //                          item:1,
   //                          slideMove:1,
   //                          slideMargin:6,
   //                        }
   //                  },
   //                  {
   //                      breakpoint:480,
   //                      settings: {
   //                          item:1,
   //                          slideMove:1
   //                        }
   //                  }
   //              ]
   //          });  
   // }); 
  </script>

  <script type="text/javascript" async >
    $('#duraion_of_hair_loss').on('change', function(){
      $('.mobile-group').show();
      //alert('hello');
    }); 
  </script>


<!-- <script>
// Set the date we're counting down to
var countDownDate = new Date("AUG 30, 2020 23:59:00").getTime();

// Update the count down every 1 second
var x = setInterval(function() {

  // Get today's date and time
  var now = new Date().getTime();
    
  // Find the distance between now and the count down date
  var distance = countDownDate - now;
    
  // Time calculations for days, hours, minutes and seconds
  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);
    
  // Output the result in an element with id="demo"
  document.getElementById("demo").innerHTML = days + " days " + hours + " hours "
  + minutes + " m <span style='color:red'>" + seconds + " s</span> ";
    
  // If the count down is over, write some text 
  if (distance < 0) {
    clearInterval(x);
    document.getElementById("demo").innerHTML = "EXPIRED";
  }
}, 1000);
</script> -->

<script type="text/javascript">

  function load_img() {
    var html = '<div class="col-md-3">'+
              '<div class="befor-img">'+
                            '<img src="img/hair/img/img-1.jpg">'+
                          '</div>'+
            '</div>'+
            '<div class="col-md-3">'+
              '<div class="befor-img">'+
                            '<img src="img/hair/img/img-3.jpg" >'+
                          '</div>'+
            '</div>'+
            '<div class="col-md-3">'+
              '<div class="befor-img">'+
                            '<img src="img/hair/img/img-4.jpg" >'+
                          '</div>'+
            '</div>'+
            '<div class="col-md-3">'+
              '<div class="befor-img">'+
                            '<img src="img/hair/img/img-5.jpg" >'+
                          '</div>'+
            '</div>';

    $("#befor_after_img").html(html);
}

$(window).on("load", load_img);

  $(document).ready(function(){   
    //var base_url = 'http://localhost/hairloss/';

    //$base_url = "https://localhost/hairandloss/";
    var base_url = "https://hairregrowth.ayushmd.com/";

    $(window).on('load',function(){
        //$('#modalRegisterForm').modal('show');
    });

    /*Enquiry PopUp start here*/ 

    $('#modalRegisterForm').modal({
        backdrop: 'static',
        keyboard: false
    });

    $('#book-an-appointment').click(function(){
        $('#modalRegisterForm').modal({
          backdrop: 'static',
          keyboard: false
      });

    });

    /*Enquiry PopUp end here*/ 

    $('.click_sumbmit').on('click', function(){

     // alert('submit');
      var gender, duraion_of_hair_loss, mobile;
      gender = $('input[name="gender"]:checked').val(); 
      // $('input["name"]').val();
      // duration_of_hair_loss = $('#duraion_of_hair_loss').val();
      // mobile = $('#mobile').val();

      //alert(duraion_of_hair_loss);

      if (gender =='Null'){
        alert('Please select gender..');
        return false;
      }
      // if (duration_of_hair_loss =='Null'){
      //   alert('Please select duration of hair loss');
      //   return false;
      // }
      // if (mobile ==''){
      //   alert('Please enter your mobile no.');
      //   return false;
      // }
      // if(mobile.length!=10){
      //    alert('Please enter 10 digit mobile no.');
      //    return false;
      // }
      if (gender !=''){

        $('#spinnder').show();
        $('#btn-text').hide();
          var url_link = base_url+'enquiry/process_enquiry.php';

        $.ajax({
          url:url_link,
          data:{
                enquiry_step:1,
                enquiry_type:'hairloss',
                gender:gender
               
                },
          type:'post',
          success:function(data){

            //alert(data);

            var dataResult = JSON.parse(data);
            // alert(data);
                    
            if (dataResult.status == 1){
              window.location=base_url+'step-one.php?g='+gender;
            }
            else{
              return false; 
            }
           
          }

        });


        //window.location='step.html';

      }

    });


  });
</script>
</body>

</html>
